#!/bin/bash

# 設定値
RESOURCE_GROUP="dxservice-ResourceGroup"
APP_NAME="dxservice-appservice-python3-s-hazeyama"
LOCATION="japanwest"
APP_SERVICE_PLAN="ASP-dxserviceResourceGroup-ba04"

echo "========================================="
echo "Azure App Service デプロイ開始"
echo "========================================="

# 1. リソースグループの作成
echo "1. リソースグループを作成中..."
az group create --name $RESOURCE_GROUP --location $LOCATION

# 2. App Service Planの作成（無料プラン）
echo "2. App Service Planを作成中..."
az appservice plan create \
  --name $APP_SERVICE_PLAN \
  --resource-group $RESOURCE_GROUP \
  --sku F1 \
  --is-linux

# 3. Web Appの作成
echo "3. Web Appを作成中..."
az webapp create \
  --resource-group $RESOURCE_GROUP \
  --plan $APP_SERVICE_PLAN \
  --name $APP_NAME \
  --runtime "PYTHON:3.10"

# 4. 環境変数の設定
echo "4. 環境変数を設定中..."
az webapp config appsettings set \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --settings \
    AZURE_OPENAI_API_KEY="$AZURE_OPENAI_API_KEY" \
    AZURE_OPENAI_ENDPOINT="$AZURE_OPENAI_ENDPOINT" \
    AZURE_OPENAI_API_VERSION="$AZURE_OPENAI_API_VERSION" \
    AZURE_OPENAI_DEPLOYMENT_NAME="$AZURE_OPENAI_DEPLOYMENT_NAME" \
    MICROSOFT_APP_ID="$MICROSOFT_APP_ID" \
    MICROSOFT_APP_PASSWORD="$MICROSOFT_APP_PASSWORD" \
    SCM_DO_BUILD_DURING_DEPLOYMENT=true

# 5. スタートアップコマンドの設定
echo "5. スタートアップコマンドを設定中..."
az webapp config set \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --startup-file "python startup.py"

# 6. デプロイ
echo "6. コードをデプロイ中..."
az webapp up \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --runtime "PYTHON:3.10" \
  --sku F1

echo "========================================="
echo "デプロイ完了！"
echo "URL: https://$APP_NAME.azurewebsites.net"
echo "エンドポイント: https://$APP_NAME.azurewebsites.net/api/messages"
echo "========================================="