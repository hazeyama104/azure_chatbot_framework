from app import APP
import os

if __name__ == "__main__":
    import aiohttp.web
    port = int(os.environ.get("PORT", 8000))
    aiohttp.web.run_app(APP, host="0.0.0.0", port=port)