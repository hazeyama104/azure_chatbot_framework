from app import APP

application = APP
